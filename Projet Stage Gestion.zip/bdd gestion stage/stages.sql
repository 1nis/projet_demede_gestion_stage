-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 02 mars 2023 à 13:22
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `stages`
--

-- --------------------------------------------------------

--
-- Structure de la table `enseigne`
--

DROP TABLE IF EXISTS `enseigne`;
CREATE TABLE IF NOT EXISTS `enseigne` (
  `NUMPROFESSEUR` int(11) NOT NULL AUTO_INCREMENT,
  `NUMCLASSE` int(11) NOT NULL,
  PRIMARY KEY (`NUMPROFESSEUR`,`NUMCLASSE`),
  KEY `I_FK_ENSEIGNE_PROFESSEUR` (`NUMPROFESSEUR`),
  KEY `I_FK_ENSEIGNE_PROMOTION` (`NUMCLASSE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `entreprise`
--

DROP TABLE IF EXISTS `entreprise`;
CREATE TABLE IF NOT EXISTS `entreprise` (
  `NUMENTREPRISE` int(11) NOT NULL AUTO_INCREMENT,
  `NUMTUTEUR` int(11) NOT NULL,
  `NOMENTREPRISE` varchar(32) DEFAULT NULL,
  `MAILENTREPRISE` varchar(32) DEFAULT NULL,
  `PDGENTREPRISE` varchar(32) DEFAULT NULL,
  `TYPEENTREPRISE` varchar(32) DEFAULT NULL,
  `SECTENREPRISE` varchar(32) DEFAULT NULL,
  `VILLEENTEPRISE` varchar(32) DEFAULT NULL,
  `CODEPOSTALEENTREPRISE` int(11) DEFAULT NULL,
  PRIMARY KEY (`NUMENTREPRISE`),
  KEY `I_FK_ENTREPRISE_TUTEUR` (`NUMTUTEUR`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `entreprise`
--

INSERT INTO `entreprise` (`NUMENTREPRISE`, `NUMTUTEUR`, `NOMENTREPRISE`, `MAILENTREPRISE`, `PDGENTREPRISE`, `TYPEENTREPRISE`, `SECTENREPRISE`, `VILLEENTEPRISE`, `CODEPOSTALEENTREPRISE`) VALUES
(2, 1, 'KALI', 'kali@kali.fr', 'ubuntu', 'dev serveur', 'machine virtuelle', 'Marseille', 13003);

-- --------------------------------------------------------

--
-- Structure de la table `etre`
--

DROP TABLE IF EXISTS `etre`;
CREATE TABLE IF NOT EXISTS `etre` (
  `NUMETUDIANT` int(11) NOT NULL AUTO_INCREMENT,
  `NUMCLASSE` int(11) NOT NULL,
  PRIMARY KEY (`NUMETUDIANT`,`NUMCLASSE`),
  KEY `I_FK_ETRE_ETUDIANT` (`NUMETUDIANT`),
  KEY `I_FK_ETRE_PROMOTION` (`NUMCLASSE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

DROP TABLE IF EXISTS `etudiant`;
CREATE TABLE IF NOT EXISTS `etudiant` (
  `NUMETUDIANT` int(11) NOT NULL AUTO_INCREMENT,
  `NOMETUDIANT` varchar(32) DEFAULT NULL,
  `PRENOMETUDIANT` varchar(32) DEFAULT NULL,
  `ADRESSEETUDIANT` varchar(32) DEFAULT NULL,
  `MAILETUDIANT` varchar(32) DEFAULT NULL,
  `DATE_NETUDIANT` date DEFAULT NULL,
  `SEXEETUDIANT` tinyint(1) DEFAULT NULL,
  `TELETUDIANT` int(11) DEFAULT NULL,
  `OPTIONETUDIANT` varchar(5) DEFAULT NULL,
  `ANNEESCOLAIRE` int(11) DEFAULT NULL,
  PRIMARY KEY (`NUMETUDIANT`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`NUMETUDIANT`, `NOMETUDIANT`, `PRENOMETUDIANT`, `ADRESSEETUDIANT`, `MAILETUDIANT`, `DATE_NETUDIANT`, `SEXEETUDIANT`, `TELETUDIANT`, `OPTIONETUDIANT`, `ANNEESCOLAIRE`) VALUES
(1, 'KHERRAF', 'ANIS', '92 Boulevard Larrat', 'anis@kherraf.fr', '2003-05-20', 1, 749300949, 'SLAM', 2021),
(2, 'vauclare', 'clement', '12 rue bla', 'clem@vauclare.com', '2003-05-20', 1, 749300946, 'SLAM', 2021),
(3, 'vauclare', 'clement', '12 rue bla', 'clem@vauclare.com', '2003-05-20', 1, 749300946, 'SLAM', 2021);

-- --------------------------------------------------------

--
-- Structure de la table `parametre`
--

DROP TABLE IF EXISTS `parametre`;
CREATE TABLE IF NOT EXISTS `parametre` (
  `NOMETABLISSEMENT` char(32) NOT NULL,
  `ADRESSEETABLISSEMENT` char(32) DEFAULT NULL,
  `CPETABLISSEMENT` char(32) DEFAULT NULL,
  `NUMETABLISSEMENT` char(32) DEFAULT NULL,
  `FAXETABLISSEMENT` char(32) DEFAULT NULL,
  `REPRESENTANT` char(32) DEFAULT NULL,
  PRIMARY KEY (`NOMETABLISSEMENT`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `professeur`
--

DROP TABLE IF EXISTS `professeur`;
CREATE TABLE IF NOT EXISTS `professeur` (
  `NUMPROFESSEUR` int(11) NOT NULL AUTO_INCREMENT,
  `NOMPROFESSEUR` varchar(32) DEFAULT NULL,
  `PRENOMPROFESSEUR` varchar(32) DEFAULT NULL,
  `NBRHEURES` int(11) DEFAULT NULL,
  `MAILPROFESSEUR` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`NUMPROFESSEUR`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `professeur`
--

INSERT INTO `professeur` (`NUMPROFESSEUR`, `NOMPROFESSEUR`, `PRENOMPROFESSEUR`, `NBRHEURES`, `MAILPROFESSEUR`) VALUES
(1, 'DEMEDE', 'Michel', 10, 'demede@free.fr');

-- --------------------------------------------------------

--
-- Structure de la table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
CREATE TABLE IF NOT EXISTS `promotion` (
  `NUMCLASSE` int(11) NOT NULL AUTO_INCREMENT,
  `NOMCLASSE` varchar(32) DEFAULT NULL,
  `ANNEE` int(11) DEFAULT NULL,
  `PROFESSEURPRINCIPAL` varchar(32) DEFAULT NULL,
  `PROFESSEURS` int(11) DEFAULT NULL,
  `NBRELEVE` int(11) DEFAULT NULL,
  PRIMARY KEY (`NUMCLASSE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `stage`
--

DROP TABLE IF EXISTS `stage`;
CREATE TABLE IF NOT EXISTS `stage` (
  `NUMSTAGE` int(11) NOT NULL AUTO_INCREMENT,
  `NUMENTREPRISE` int(11) NOT NULL,
  `NUMTUTEUR` int(11) NOT NULL,
  `NUMPROFESSEUR` int(11) NOT NULL,
  `NUMETUDIANT` int(11) NOT NULL,
  `DDSTAGE` date DEFAULT NULL,
  `DFSTAGE` date DEFAULT NULL,
  `SJSTAGE` varchar(32) DEFAULT NULL,
  `NBRSEMAINE` int(11) DEFAULT NULL,
  `RPST_STAGE` varchar(32) DEFAULT NULL,
  `CP_ASS` varchar(32) DEFAULT NULL,
  `C_ASS` varchar(32) DEFAULT NULL,
  `NUM_CONTR` int(11) DEFAULT NULL,
  PRIMARY KEY (`NUMSTAGE`),
  KEY `I_FK_STAGE_ENTREPRISE` (`NUMENTREPRISE`),
  KEY `I_FK_STAGE_TUTEUR` (`NUMTUTEUR`),
  KEY `I_FK_STAGE_PROFESSEUR` (`NUMPROFESSEUR`),
  KEY `I_FK_STAGE_ETUDIANT` (`NUMETUDIANT`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `stage`
--

INSERT INTO `stage` (`NUMSTAGE`, `NUMENTREPRISE`, `NUMTUTEUR`, `NUMPROFESSEUR`, `NUMETUDIANT`, `DDSTAGE`, `DFSTAGE`, `SJSTAGE`, `NBRSEMAINE`, `RPST_STAGE`, `CP_ASS`, `C_ASS`, `NUM_CONTR`) VALUES
(1, 2, 1, 1, 2, '2023-01-03', '2023-02-17', 'Dév Web', 6, 'Olivier', 'Ameli', 'Maif', 1979793637),
(2, 2, 1, 1, 1, '2023-01-03', '2023-02-17', 'Dév Web', 6, 'Olivier', 'Ameli', 'Maif', 1979793637);

-- --------------------------------------------------------

--
-- Structure de la table `tuteur`
--

DROP TABLE IF EXISTS `tuteur`;
CREATE TABLE IF NOT EXISTS `tuteur` (
  `NUMTUTEUR` int(11) NOT NULL AUTO_INCREMENT,
  `NOMTUTEUR` varchar(32) DEFAULT NULL,
  `PRENOMTUTEUR` varchar(32) DEFAULT NULL,
  `FONCTION` varchar(32) DEFAULT NULL,
  `ENTREPRISETUTEUR` varchar(32) DEFAULT NULL,
  `NBRSTAGIAIRE` int(11) DEFAULT NULL,
  PRIMARY KEY (`NUMTUTEUR`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tuteur`
--

INSERT INTO `tuteur` (`NUMTUTEUR`, `NOMTUTEUR`, `PRENOMTUTEUR`, `FONCTION`, `ENTREPRISETUTEUR`, `NBRSTAGIAIRE`) VALUES
(1, 'Tahiti', 'Bob', 'Dev Full Stack', 'Kali', 2);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `enseigne`
--
ALTER TABLE `enseigne`
  ADD CONSTRAINT `enseigne_ibfk_1` FOREIGN KEY (`NUMPROFESSEUR`) REFERENCES `professeur` (`NUMPROFESSEUR`),
  ADD CONSTRAINT `enseigne_ibfk_2` FOREIGN KEY (`NUMCLASSE`) REFERENCES `promotion` (`NUMCLASSE`);

--
-- Contraintes pour la table `entreprise`
--
ALTER TABLE `entreprise`
  ADD CONSTRAINT `entreprise_ibfk_1` FOREIGN KEY (`NUMTUTEUR`) REFERENCES `tuteur` (`NUMTUTEUR`);

--
-- Contraintes pour la table `etre`
--
ALTER TABLE `etre`
  ADD CONSTRAINT `etre_ibfk_1` FOREIGN KEY (`NUMETUDIANT`) REFERENCES `etudiant` (`NUMETUDIANT`),
  ADD CONSTRAINT `etre_ibfk_2` FOREIGN KEY (`NUMCLASSE`) REFERENCES `promotion` (`NUMCLASSE`);

--
-- Contraintes pour la table `stage`
--
ALTER TABLE `stage`
  ADD CONSTRAINT `stage_ibfk_1` FOREIGN KEY (`NUMENTREPRISE`) REFERENCES `entreprise` (`NUMENTREPRISE`),
  ADD CONSTRAINT `stage_ibfk_2` FOREIGN KEY (`NUMTUTEUR`) REFERENCES `tuteur` (`NUMTUTEUR`),
  ADD CONSTRAINT `stage_ibfk_3` FOREIGN KEY (`NUMPROFESSEUR`) REFERENCES `professeur` (`NUMPROFESSEUR`),
  ADD CONSTRAINT `stage_ibfk_4` FOREIGN KEY (`NUMETUDIANT`) REFERENCES `etudiant` (`NUMETUDIANT`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
